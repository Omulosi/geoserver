GeoServer README
----------------

For more information about the GeoServer project visit the web site at:

  http://geoserver.org


Documentation can be found at:

  http://docs.geoserver.org/


To file a bug report or issue please visit:

  https://osgeo-org.atlassian.net/projects/GEOS


For help and support please email the GeoServer users group:

  geoserver-users@lists.sourceforge.net


Thanks for using GeoServer!
